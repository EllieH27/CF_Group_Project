import main_window

main_window.download_all_files()
